/*
 * pruebas.cpp
 *
 *  Created on: 7 de dic. de 2016
 *      Author: Jose Juan Peña Gomez y Sergio Gomez Soto
 */
#include "entorno.h"

#include <stdlib.h>

#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include "pruebasEntorno.h"

using namespace std;

void pruebasEntornoCargarConfiguracion(){
	int numpiezas, tamtab, maxpunt;

	cout << "Inicio de pruebas entornoCargarConfiguracion " << endl;
	if( entornoCargarConfiguracion(tamtab, maxpunt, numpiezas)){
		cout << "Correcto" << endl;
		cout << "El tamaño del tablero es " << tamtab << " ,la maxima puntuacion es " << maxpunt;
		cout << "y el numero de piezas es " << numpiezas << endl;
	}else{
		cout << "Incorrecto" << endl;
	}

}
//guardarconfig como el de antes y decir en un cout que revise el archivo 1010.cnp que tendra la configuracion guardada tal
void pruebasEntornoGuardarConfiguracion(){
	int tamanio1=10;
	int maxpunt=1000;
	int numpiez=3;
	cout << "Inicio de pruebas entornoGuardarConfiguracion" << endl;
	entornoGuardarConfiguracion(tamanio1, maxpunt, numpiez);

	cout << "Revisa si en el archivo 1010!.cnf si es esa la configuracion guardada(tamanio1=10; maxpunt=1000; numpiez=3)" << endl;

	entornoPausa(2); //para que no se realicen todas los modulos a la vez
}
void pruebasEntornoColorearCasilla(){
	 cout << "Inicio de pruebas de entornoColorearCasilla" << endl;

     entornoColorearCasilla(0,0, COLOR_AZUL);
	 entornoColorearCasilla(0,1, COLOR_AZUL);
	 entornoColorearCasilla(0,2, COLOR_AZUL);
     cout << "Se pintan las casillas (0,1),(0,2),(0,3) con el color azul" << endl;

     entornoPausa(2);
}
void pruebasEntornoBorrarCasilla(){
	cout << "Inicio de pruebas de entornoBorrarCasilla" << endl;

	entornoBorrarCasilla(0,0);
	entornoBorrarCasilla(0,1);
	entornoBorrarCasilla(0,2);

	cout << "Se borran las casillas (0,1),(0,2),(0,3)" << endl;
	entornoPausa(2);

}
void pruebasEntornoPintarPieza(){
	cout << "Inicio de pruebas de entornoPintarPieza" << endl;

	entornoPintarPieza(Zona1 ,1,3, COLOR_FUCSIA);
	entornoPintarPieza(Zona2 ,3,1, COLOR_MARRON);
	entornoPintarPieza(Zona3 ,1,1, COLOR_AZUL);

    cout << "Se pinta una pieza 1x3 en la zona1, una 3x1 en la zona2 y una 1x1 en la zona3" << endl;
    entornoPausa(2);
}
void pruebasEntornoPintarPiezaCuadrada(){
	cout << "Inicio de pruebas de entornoColearCasilla" << endl;

	entornoPintarPieza(Zona1, 1, 1, 2);
	entornoPintarPieza(Zona2, 2, 2, 2);
	entornoPintarPieza(Zona2, 3, 3, 2);

	cout << "Pinta una pieza cuadrada de 1x1 en la zona1, una 2x2 en la zona 2 y 3x3 en la zona3" << endl;
	entornoPausa(2);
}
void pruebasEntornoEliminarPieza(){
	cout << "Inicio de pruebas de entornoEliminarPieza" << endl;

	entornoEliminarPieza(Zona1);
	entornoEliminarPieza(Zona2);
	entornoEliminarPieza(Zona3);
	cout << "Se eliminan las piezas credas anteriormente en la zona 1, 2 y 3" << endl;
	entornoPausa(2);
}
void pruebasEntornoActivarCasilla(){
	cout << "Inicio de pruebas de entornoActivarCasilla" << endl;

	entornoActivarCasilla(2,3);

	cout << "Enmarca la casilla (2,3) en azul" << endl;
	entornoPausa(2);
}
void pruebasEntornoDesactivarCasilla(){
	cout << "Inicio de pruebas de entornoDesactivarCasilla" << endl;

	entornoDesactivarCasilla(2,3);

	cout << "Elimina el marco anterior creado de la casilla (2,3)" << endl;
	entornoPausa(2);
}
void pruebasEntornoPuntuacionMaxima(){
	cout << "Inicio de pruebas de entornoPuntuacionMaxima" << endl;

	entornoPuntuacionMaxima(750);

	cout << "Debe mostrar en la parte superior 750 como puntuacion maxima" << endl;
	entornoPausa(2);
}
void pruebasEntornoPonerPuntuacion(){
	cout << "Inicio de pruebas de entornoPonerMaxima" << endl;

	entornoPonerPuntuacion(345);

	cout << "Muestra en la parte superior 345 como puntuacion actual" << endl;
	entornoPausa(2);
}
void pruebasEntornoMostrarMensaje(){
	cout << "Inicio de pruebas de entornoMostrarMensaje" << endl;
	string juegoDivertido;

	entornoMostrarMensaje(Zona1, juegoDivertido);

	cout << "Muestra en la zona1 el mensaje juegoDivertido" << endl;
	entornoPausa(2);
}
void pruebasEntornoMostrarMensajeFin(){
	cout << "Inicio de pruebas de entornoMostrarMensajeFin" << endl;

	string FINAL;

	entornoMostrarMensajeFin(FINAL);

	cout << "Muestra en medio de la pantalla FINAL como mensaje final" << endl;
	entornoPausa(2);
}
void pruebasEntornoPausa(){
	cout << "Inicio de pruebas de entornoPausa" << endl;

	entornoPausa(5);

	cout << "Debe pararse el programa durante 5 segundos" << endl;
}

































