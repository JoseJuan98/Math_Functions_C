/*
 * pruebas.h
 *
 *  Created on: 7 de dic. de 2016
 *      Author: Jose Juan Peña Gomez y Sergio Gomez Soto
 */

#ifndef PRUEBASENTORNO_H_
#define PRUEBASENTORNO_H_

#include <iostream>
#include <string>
using namespace std;

/* POST=Carga una configuracion dando valor a los parametros del tamaño del tablero,
 * Complejidad: O(1)
 */
void pruebasEntornoCargarConfiguracion();
/* POST=Guarda la configuracion que le pases a traves de parametros en el archivo 1010!.cnf
 * Complejidad: O(1)
 */
void pruebasEntornoGuardarConfiguracion();
/* POST=colorea la casilla indicada
 * Complejidad: O(1)
 */
void pruebasEntornoColorearCasilla();

/* POST= borra la casilla indicada
 * Complejidad: O(1)
 */

void pruebasEntornoBorrarCasilla();

/* POST= pinta la pieza indicada a partir de una casilla determinada
 * Complejidad: O(1)
 */

void pruebasEntornoPintarPieza();
/* POST= pinta una pieza cuadrada a partir de una casilla determinada
 * Complejidad: O(1)
 */

void pruebasEntornoPintarPiezaCuadrada();

/* POST= elimina una pieza en una zona indicada
 * Complejidad: O(1)
 */

void pruebasEntornoEliminarPieza();

/* POST= remarca en azul la casilla indicada
 * Complejidad: O(1)
 */

void pruebasEntornoActivarCasilla();

/* POST= quita la marca azul que remarca el modulo EntornoActivarCasilla
 * Complejidad: O(1)
 */

void pruebasEntornoDesactivarCasilla();

/* POST= pone una puntuacion maxima en la parte superior
 * Complejidad: O(1)
 */

void pruebasEntornoPuntuacionMaxima();

/* POST= pone una puntuacion actual
 * Complejidad: O(1)
 */

void pruebasEntornoPonerPuntuacion();

/* POST= muestra un mensaje en una zona indicada
 * Complejidad: O(1)
 */

void pruebasEntornoMostrarMensaje();

/* POST= muestra el mensaje final en medio de la pantalla
 * Complejidad: O(1)
 */

void pruebasEntornoMostrarMensajeFin();

/* POST=  pausa el juego
 * Complejidad: O(1)
 */

void pruebasEntornoPausa();


#endif /* PRUEBASENTORNO_H_ */
