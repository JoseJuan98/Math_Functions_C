//============================================================================
// Name        : TadSeguridad.h
// Author      : Profesores de la asignatura IP
// Version     : Curso 2016/17
// Copyright   : Your copyright notice
// Description : Definición de tipo de datos seguridad y operaciones
//============================================================================

#ifndef SEGURIDAD_H_
#define SEGURIDAD_H_
#include <string>   // necesaria para trabajar con string
using namespace std;

const int DIASCADUCIDAD=60;
const int MAX=500;

struct Usuario{
	string nombre;
	string contrasena;
	int    diasCaducidad;
};

typedef Usuario TVectorSeguridad[MAX];

struct  Seguridad{
	TVectorSeguridad vectorSeg;
	int              ocupadas;
};

/*
 * PRE:  {}
 * POST: { iniciliza la ED ocupadas=0 }
 * COMPLEJIDAD: O(1)
 */
void iniciar    (Seguridad &s);
/*
 * PRE:  { S inicializado and nombre <> empty and pwd <> empty}
 * POST: { Inserta el usuario al final si no existe.
 *         Si existe actualiza la contraseña}
 * COMPLEJIDAD: O(n)
 */
void insertar    (Seguridad &s, string nombre, string pwd);

/*
 * PRE:  {s debe estar inicializado}
 * POST: {resta 1 los dias de caducidad de contraseña y devuelve el numero de contraseñas caducadas}
 * COMPLEJIDAD: O(n)
 */
int  actualizar   (Seguridad &s);

/*
 * PRE:  {s debe estar inicializado}
 * POST: {devuelve si existe un usuario o no y si existe devuelve la contraseña}
 * COMPLEJIDAD: O(n)
 */
bool queContrasena (Seguridad s, string nombre, string &pwd);

/*
 * PRE:  {s debe estar inicializado}
 * POST: {devuelve todos los nombres y contraseñas de cada usuario}
 * COMPLEJIDAD: O(n)
 */
void mostrar        (Seguridad s);

/*
 * PRE:  {s debe estar inicializado}
 * POST: {devuelve el numero de usuarios}
 * COMPLEJIDAD: O(1)
 */
int cuantos         (Seguridad s);

#endif /* SEGURIDAD_H_ */
