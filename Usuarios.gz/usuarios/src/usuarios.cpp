//============================================================================
// Name        : Usuarios.cpp
// Author      : Profesores de la asignatura IP
// Version     : Curso 2016/17
// Description : USuarios: Examen de enero de 2012
//============================================================================

#include <iostream>
#include "seguridad.h"
#include "pruSeguridad.h"
using namespace std;

int menu (){
	int opcion;
	cout <<endl<<endl;
	cout << "1.- Insertar usuario "<< endl;
	cout << "2.- Actualizar       "<< endl;
	cout << "3.- Qué contraseña   "<< endl;
	cout << "4.- Mostrar          "<< endl;
	cout <<endl;
	cout << "5.- Terminar         "<< endl;
	do {
  	      cin >> opcion;
	} while (opcion <1 || opcion > 5);
	return opcion;
}

void ejecutar (){
	    int       numCaducadas,
		          opcion;

		bool      salir;

		string    nombre,
			      pwd;

		Seguridad seguridad;

		opcion  = 0;
		salir   = false;
		iniciar(seguridad);

		while (!salir){
			opcion = menu();
			cin.ignore();

			switch (opcion){
			case 1:
				cout << "Introduce los siguientes datos :"<< endl;
				cout << "Nombre     : ";
				getline(cin, nombre);
				cout << "Contraseña : ";
				getline (cin, pwd);
				insertar (seguridad, nombre, pwd);
				break;
			case 2:
				numCaducadas = actualizar(seguridad);
				cout << "Nº de contraseñas caducadas "<< numCaducadas<< endl;
				break;
			case 3:
				cout << "Nombre          : ";
				getline(cin, nombre);
				if (queContrasena(seguridad, nombre, pwd))
					cout <<"Su contraseña es : "<< pwd;
				else cout <<"El usuario no existe";

				break;
			case 4:
				mostrar(seguridad);
				break;
			case 5:
				salir = true;
				break;
			}

		}


}


int main() {
	// pruebas();
	ejecutar();
	return 0;
}


