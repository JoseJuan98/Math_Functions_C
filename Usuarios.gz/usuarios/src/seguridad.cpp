//============================================================================
// Name        : TadSeguridad.cpp
// Author      : Profesores de la asignatura IP
// Version     : Curso 2016/17
// Copyright   : Your copyright notice
// Description : Implementación de las operaciones para el  tipo de datos seguridad
//============================================================================

#include "seguridad.h"
#include <iostream>
using namespace std;

void iniciar(Seguridad &s) {
		s.ocupadas = 0;
}

void insertar(Seguridad &s, string nombre, string pwd) {
	int i;

	for(i=0; i<MAX; i++){
		if(s.vectorSeg[i].nombre == nombre){
			s.vectorSeg[i].contrasena = pwd;
			s.vectorSeg[i].diasCaducidad = DIASCADUCIDAD;
		}else{
			if(s.ocupadas < MAX){
				s.vectorSeg[s.ocupadas].nombre = nombre;
				s.vectorSeg[i].contrasena = pwd;
				s.vectorSeg[i].diasCaducidad =DIASCADUCIDAD;
			}
		}
	}

}

int actualizar(Seguridad &s) {
	int i, contracaducadas;

	for(i=0; i<MAX; i++){
		s.vectorSeg[i].diasCaducidad = s.vectorSeg[i].diasCaducidad + 1;

		if(s.vectorSeg[i].diasCaducidad == 0){
			contracaducadas = contracaducadas +1;
		}
	}
return contracaducadas;
}

bool queContrasena(Seguridad s, string nombre, string &pwd) {
	bool hayUs;
	int i;
	hayUs = false;

	for(i=0; i<MAX; i++){
		if(s.vectorSeg[i].nombre == nombre){
			hayUs = true;
			pwd = s.vectorSeg[i].contrasena;
		}
	}
return hayUs;
}

int cuantos(Seguridad s) {
	int usuarios;
	usuarios = s.ocupadas - 1;

return usuarios;
}

// recorre el vector y muestra la inf en pantalla
void mostrar(Seguridad s) {
	int i;

	for(i=0; i<MAX; i++){
		cout << "Usuario:  " << s.vectorSeg[i].nombre << "  Contraseña:  " << s.vectorSeg[i].contrasena << endl;

	}
}
