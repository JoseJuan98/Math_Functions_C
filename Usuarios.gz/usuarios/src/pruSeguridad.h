//============================================================================
// Name        : Pruebas TadSeguridad.h
// Author      : Profesores de la asignatura IP
// Version     : Curso 2016/17
// Copyright   : Your copyright notice
// Description : Diseño de pruebas
//============================================================================


#ifndef PRUSEGURIDAD_H_
#define PRUSEGURIDAD_H_

#include "seguridad.h"


/*
 * Al iniciar la función cuantos debe devolver 0, vov vacio
 */
void pruebaIniciar    ();

/*
 * Casos de prueba sobre un vov "S" inicializado. Ocupación = 0
 *
 * caso dato             ocupadas antes  posición de inserción  ocupadas después
 * _______________________________________________________________________________
 *   1 mariscal	tuMismo	       0 				S[0]			1
 *   2 gomez    cualquiera     1				S[1]			2
 *   3 vicente  siempreAsi     2				S[2]			3
 *   4 jurado	esEsa		   3				S[3]			4
 *
 * Estado del vector después de las inserciones. Ocupación = 4
 *   S[0]        S[1]            S[2]        S[3]
 *   ̣̣̣_____________________________________________________
 *   mariscal	gomez			vicente		jurado
 *   tuMismo	cualquiera	  siempreAsi	esEsa
 *   60			60				60			60
 *
 */
void pruebaInsertar       ();

/*
 * Casos de prueba sobre un vov "S" inicializado con 4 elementos insertados
 * Estado inicial. Ocupación = 4
 *   S[0]        S[1]            S[2]        S[3]
 *   ̣̣̣_____________________________________________________
 *   mariscal	gomez			vicente		jurado
 *   tuMismo	cualquiera	siempreAsi	esEsa
 *   60			60				60			60
 *
 *
 * caso    Nº actualizaciones   dias para caducar   Nº de caducadas
 * ________________________________________________________________
 *   1			1						59          	0
 *   2			29						30				0
 *   Insertamos un nuevo usuario - Tendrá 60 días para caducar
 *   3			30						0				4
 *
 */
void pruebaActualizar     ();

/*
 * Casos de prueba sobre un vov "S" inicializado con 4 elementos insertados
 * Estado inicial. Ocupación = 4
 *   S[0]        S[1]            S[2]        S[3]
 *   ̣̣̣_____________________________________________________
 *   mariscal	gomez			vicente		jurado
 *   tuMismo	cualquiera	siempreAsi	esEsa
 *   60			60				60			60
 *
 * caso    dato    posición en el vector       salida
 * __________________________________________________________
 *   1	"mariscal"	 S[0] inicio	          true / tuMismo
 *   2	"vicente"    S[2] intermedia	      true / siempreAsi
 *   3	"jurado"     S[3] final				  true / esEsa
 *   4  "adrian"     No se encuentra		  false/ --
 *
 */
void pruebaQueContrasena ();
/*
* caso   Estado del vov        salida
* __________________________________________________________
*   1	 Inicializado             0
*   2	 inserto 1 elemento       1
*   3	 inserto 3 elementos más  4
*/

void pruebaCuantos        ();

/*
* Casos de prueba sobre un vov "S"
* Caso 1. S incinicializado
*         Salida esperada: 0 elementos
*
* Caso 2. Inserto 2 elementos
* 		   S[0]        S[1]
*   ̣̣̣      ________________________
*       	mariscal	gomez
*   		tuMismo	   cualquiera
* 			  60		60
* 		  Salida esperada: 2 elementos
* 		 	Nombre: mariscal	tuMismo		    60
* 			Nombre: gomez		cualquiera      60
*
* Caso 3. Inserto 2 elementos más
*            S[2]        S[3]
*           ___________________
*			vicente		jurado
*			siempreAsi	esEsa
*			60			60
*
*  		  Salida esperada: 4 elementos
* 			Nombre: mariscal	tuMismo		    60
* 			Nombre: gomez		cualquiera      60
* 			Nombre: vicente	    siempreAsi		60
* 			Nombre: jurado	    esEsa			60
*
*/
void pruebaMostrar        ();

// Todas las pruebas
void pruebas ();

#endif /* PRUSEGURIDAD_H_ */
