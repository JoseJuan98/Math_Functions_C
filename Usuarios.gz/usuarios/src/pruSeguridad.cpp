//============================================================================
// Name        : Pruebas TadSeguridad.h
// Author      : Profesores de la asignatura IP
// Version     : Curso 2015/16
// Copyright   : Your copyright notice
// Description : Implementación de pruebas
//============================================================================

#include "pruSeguridad.h"
#include <iostream>
using namespace std;

void pruebaIniciar() {
	cout << "INICIO: PRUEBAS INICIAR...." << endl;
	Seguridad s;
	iniciar(s);
	if (cuantos(s) != 0)
		cout << "ERROR INICIAR: no tiene 0 elementos"<<endl;;
	cout << "FIN: PRUEBAS INICIAR" << endl;
}

void pruebaInsertar() {

	Seguridad s;

	cout << "INICIO: PRUEBAS INSERTAR...." << endl;
	iniciar(s);
	//caso 1: inserto en la primera posición, el vov está vacío
	insertar(s, "mariscal", "tuMismo");
	if (cuantos(s) != 1)
		cout << "ERROR: Fallo en el insertar cuando el vov está vacio";
	else
		mostrar(s);
	cout << endl;
	// caso 2: inserto al final. Existe al menos un elemento
	insertar(s, "gomez", "cualquiera");
	if (cuantos(s) != 2)
		cout << "ERROR: Fallo en el insertar final";
	else
		mostrar(s);
	cout << endl;
	// caso 3: inserto al final. Existe más de dos elementos
	insertar(s, "vicente", "siempreAsi");
	if (cuantos(s) != 3)
		cout << "ERROR: Fallo en el insertar final";
	else
		mostrar(s);
	cout << endl;
	// caso 4: inserto al final. Existe más de dos elementos
	insertar(s, "jurado", "esEsa");
	if (cuantos(s) != 4)
		cout << "ERROR: Fallo en el insertar final";
	else
		mostrar(s);
	cout << "FIN: PRUEBAS INSERTAR" << endl;
}

void pruebaActualizar() {
	int i, numCaducadas;

	Seguridad s;
	cout << "INICIO: PRUEBAS ACTUALIZAR...." << endl;
	iniciar(s);

	insertar(s, "mariscal", "tuMismo");
	insertar(s, "gomez"   , "cualquiera");
	insertar(s, "vicente" , "siempreAsi");
	insertar(s, "jurado"  , "esEsa");
	// caso 1
	cout << "Actualizo 1 vez "<< endl;
	if (actualizar(s) != 0)
		cout << "ERROR ACTUALIZAR: no puede haber contraseñas caducadas"
				<< endl;
	mostrar(s);

	// caso 2:
	cout << "Actualizo 29 veces "<< endl;
	for (i = 1; i < 30; i++) {
		numCaducadas=actualizar(s);
	}
	if (numCaducadas!=0)
		cout << "ERROR ACTUALIZAR: No debe caducar ninguna" << endl;

	mostrar(s);
	// Insertamos un nuevo elemento que tendrá una caducidad de 60
	insertar(s, "elemento", "miClave");

	// caso 3:
	cout << "Actualizo 30 veces más "<< endl;
	for (i = 0; i < 30; i++) {
		numCaducadas = actualizar(s);
	}
	if (numCaducadas != 4) {
		cout << "ERROR ACTUALIZAR: deben caducar 4" << endl;
	}

	mostrar(s);
	cout << "FIN: PRUEBAS ACTUALIZAR" << endl;
}

void pruebaQueContrasena() {
	bool encontrado;
	string pwd;
	Seguridad s;
	cout << "INICIO: PRUEBAS QUE CONTRASEÑA...." << endl;
	iniciar(s);

	insertar(s, "mariscal", "tuMismo");
	insertar(s, "gomez", "cualquiera");
	insertar(s, "vicente", "siempreAsi");
	insertar(s, "jurado", "esEsa");

	// caso 1, el dato está y se encuentra al inicio del Vov
	encontrado = queContrasena(s, "mariscal", pwd);
	if (!encontrado) {
		cout << "ERROR QUE CONTRASEÑA: al buscar al inicio del vector" << endl;
		if (pwd != "tuMismo")
			cout << "ERROR QUE CONTRASEÑA: al devolver la contraseña" << endl;
	}
	// caso 2, el dato está y se encuentra en una posición intermedia
	encontrado = queContrasena(s, "vicente", pwd);
	if (!encontrado) {
		cout
				<< "ERROR QUE CONTRASEÑA: al buscar en posición intermedia del vector"
				<< endl;
		if (pwd != "siempreAsi")
			cout << "ERROR QUE CONTRASEÑA: al devolver la contraseña" << endl;
	}
	// caso 3, el dato está y se encuentra al final
	encontrado = queContrasena(s, "jurado", pwd);
	if (!encontrado) {
		cout << "ERROR QUE CONTRASEÑA: al buscar al final del vector" << endl;
		if (pwd != "esEsa")
			cout << "ERROR QUE CONTRASEÑA: al devolver la contraseña" << endl;
	}
	// caso 4, el dato no se encuentra en el vov
	encontrado = queContrasena(s, "adrian", pwd);
	if (encontrado){
		cout << "ERROR QUE CONTRASEÑA: al buscar un dato que no existe" << endl;
	}
	cout << "FIN: PRUEBAS QUE CONTRASEÑA" << endl;
}
void pruebaCuantos() {
	Seguridad s;
	cout << "INICIO: PRUEBAS CUANTOS...." << endl;
	iniciar(s);
	// caso 1
	if (cuantos(s) != 0)
		cout << "ERROR CUANTOS: cuando está vacio";
	// caso 2
	insertar(s, "mariscal", "tuMismo");
	if (cuantos(s) != 1)
		cout << "ERROR CUANTOS: cuando hay un elemento";
	// caso 3
	insertar(s, "gomez", "cualquiera");
	insertar(s, "vicente", "siempreAsi");
	insertar(s, "jurado", "esEsa");
	if (cuantos(s) != 4)
		cout << "ERROR CUANTOS: cuando hay cuatro elementos";

	cout << "FIN: PRUEBAS CUANTOS...." << endl;

}
void pruebaMostrar() {
	Seguridad s;
		cout << "INICIO: PRUEBAS MOSTRAR...." << endl;
		iniciar(s);
		// caso 1
		mostrar(s);
		// caso 2
		insertar(s, "mariscal", "tuMismo");
		insertar(s, "gomez",    "cualquiera");
		mostrar(s);
		// caso 3
		insertar(s, "vicente",  "siempreAsi");
		insertar(s, "jurado",   "esEsa");
		mostrar(s);
		cout << "FIN: PRUEBAS MOSTRAR...." << endl;

}

void pruebas() {
	cout <<"Inicio pruebas.........."<<endl;
    pruebaIniciar();
	pruebaInsertar();
	pruebaCuantos();
	pruebaMostrar();
	pruebaActualizar();
	pruebaQueContrasena();
	cout <<"Fin pruebas............"<<endl;
}


